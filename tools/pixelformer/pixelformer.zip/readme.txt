Pixelformer used to generate Alpha BMP images for Inno Setup
Version 0.9.6.3 RC3
https://www.qualibyte.com/
